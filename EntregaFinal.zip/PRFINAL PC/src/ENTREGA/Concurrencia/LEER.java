package ENTREGA.Concurrencia;

public class LEER {
	
	/* En esta carpeta estan los tres m�todos de concurrencia.
	 * - 1. Cerrojos (Locks): Usamos la clase creada en la practica 2, el algoritmo de Ticket.
	 * - 2. Semaforos: Usamos la clase Semaphore de java.
	 * - 3. Monitores: Usando ReentrantLock
	 */
	
}
