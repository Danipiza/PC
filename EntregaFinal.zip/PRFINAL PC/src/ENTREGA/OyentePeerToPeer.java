package ENTREGA;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import ENTREGA.Concurrencia.Monitor.MonitorConexion;

@SuppressWarnings("unused")
public class OyentePeerToPeer extends Thread {

	private Socket sc1;	
	private ServerSocket servidor2;
	
	private DataInputStream inSC1;
	private DataOutputStream outSC1;
	
	private String conexion;	
	private TablaConcurrencia tConcurrencia;
	
	
	public OyentePeerToPeer(Socket sc1, ServerSocket servidor2, TablaConcurrencia tConcurrencia,
			String conexion) {
		this.sc1 = sc1;
		this.servidor2 = servidor2;
		this.conexion = conexion;
		this.tConcurrencia = tConcurrencia;
	}
	
	@Override
	public void run() {
		try {
			
			sc1 = new Socket(tConcurrencia.getHostMonitor(), 
					tConcurrencia.getPuertoMonitor());			
			
			tConcurrencia.aumentaPuertoMonitor();
			
			inSC1 = new DataInputStream(sc1.getInputStream());			
			outSC1 = new DataOutputStream(sc1.getOutputStream());
			
			// Mientras que haya conexion se mantiene en el bucle
			tConcurrencia.esperaFinConexionMonitor(conexion);			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
