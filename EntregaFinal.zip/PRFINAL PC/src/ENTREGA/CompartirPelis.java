package ENTREGA;

import java.util.Scanner;
import ENTREGA.Concurrencia.Clases.Entero;

// Main donde estan las variables de la concurrencia
public class CompartirPelis {
	
	
	public volatile Entero[] turno;
	
	
	
	public CompartirPelis() {			
		mainPRFinal();
	}
	
	// Inicializa el vector de turnos del Lock
	private void init(int N) {
		for(int i = 0; i < N; i++) {			
			turno[i] = new Entero(-1);
		}
	}
	
	private void mainPRFinal() {
		@SuppressWarnings("resource")
		Scanner sn = new Scanner(System.in);
		int N = 1; // Numero de Clientes que va haber conectados
				
		try {			
			
			System.out.print("Cuantos clientes quieres conectar: ");
			N = sn.nextInt();
			
			turno = new Entero[N];
			init(N);
			TablaConcurrencia tConcurrencia = new TablaConcurrencia(turno);
			
			// Crea el servidor
			Servidor s = new Servidor(tConcurrencia);
			s.start();	
			
			// Crea los clientes
			Cliente[] clientes = new Cliente[N];
			for(int i = 0; i < N; i++) {
				clientes[i] = new Cliente(i, tConcurrencia);
				
				clientes[i].start();	
			}		
			
						
			// Finaliza los hilos creados (Servidor y Clientes)
			// Da igual porque hay un bucle infinito
			s.join();
			for(int i = 0; i < N; i++) {
				clientes[i].join();		
			}
			
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		
	}
	
}
