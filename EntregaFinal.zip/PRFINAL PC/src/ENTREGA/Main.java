package ENTREGA;

public class Main {
		
	public static void main(String[] args) throws InterruptedException {
		@SuppressWarnings("unused")
		CompartirPelis main = new CompartirPelis();	
	}

}
