package ENTREGA;

import java.util.HashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

import ENTREGA.Concurrencia.Clases.Entero;
import ENTREGA.Concurrencia.Lock.AlgoritmoTicket;
import ENTREGA.Concurrencia.Monitor.MonitorConexion;
import ENTREGA.Concurrencia.Monitor.MonitorLock;

public class TablaConcurrencia {

		// Variables para el Lock.
		// Se usa para que los clientes se conecten correctamente
		private volatile AtomicInteger ticket;
		private Entero next;
		private Entero[] turno;
		private AlgoritmoTicket TicketClase;
		
		// Monitor
		private MonitorLock mPidePeli;
		private MonitorConexion mConexion;
		
		// Semaforos
		private Semaphore sem, semServidor;
		private Entero entero, numHilos;
		private HashMap<String, Boolean> mapaClienteActivo;			
		
		public TablaConcurrencia(Entero[] turno) {			
			// Lock -------------------------------
			this.ticket = new AtomicInteger(0);
			this.next = new Entero(0);
			this.turno = turno;
			this.TicketClase = new AlgoritmoTicket();
			// Monitores --------------------------
			this.mPidePeli = new MonitorLock();
			this.mConexion = new MonitorConexion(5001);
			// Semaforo ---------------------------
			this.sem = new Semaphore(1);
			this.entero = new Entero(0);
			this.numHilos = new Entero(0);
			this.semServidor = new Semaphore(1);
			this.mapaClienteActivo = new HashMap<String, Boolean>(); 
		}
		
		// Concurrencia de los clientes, mediante cerrojo
		// Usamos el algoritmo de Ticket
		public void takeLock(int numCliente) {
			TicketClase.TakeLock(numCliente, ticket, next, turno);	
		}		
		public void releaseLock() {
			TicketClase.ReleaseLock(ticket, next, turno);				
		}
		
		// Semaforos
		public void clienteActivoSem(String IDCliente) throws InterruptedException {
			semServidor.acquire();
			mapaClienteActivo.put(IDCliente, true);			
			semServidor.release();
		}		
		public void clienteInactivoSem(String IDCliente) throws InterruptedException {
			semServidor.acquire();
			mapaClienteActivo.put(IDCliente, false);			
			semServidor.release();
		}
		
		public void esperaClienteInactivoSem(String usuario) {
			while(mapaClienteActivo.get(usuario)) { }
		}
		
		public void modifAccedTUsuariosSem(int valor) throws InterruptedException {
			sem.acquire();
			if(entero.getValor() != 0 && entero.getValor() != valor){
				sem.release();
				while(entero.getValor() != 0 && entero.getValor() != valor){ }
				sem.acquire();					
			} 						
			entero.setValor(valor);	
			numHilos.addValor(1);
			sem.release();				
		}
		
		public void restaHilosSem() throws InterruptedException {
			sem.acquire();
			numHilos.restaValor(1);
			sem.release();
		}
		
		public void setValorCeroSem() throws InterruptedException {
			sem.acquire();		
			 if(numHilos.getValor() == 0) {
				entero.setValor(0);				
			}
			sem.release();
		}
	
		
		// Monitor
		public boolean getPideFichMonitor(String IDCliente){
			return mPidePeli.getPideFich(IDCliente);
		}
		public void pideFichTrueMonitor(String IDCliente) {
			mPidePeli.pideFichTrue(IDCliente);
		}
		public void pideFichFalseMonitor(String IDCliente) {
			mPidePeli.pideFichFalse(IDCliente);
		}
		
		public void conexionFalseMonitor(String IDCliente) {
			mConexion.conexionFalse(IDCliente, 0);
		}
		public int getPuertoMonitor() {
			return mConexion.getPuerto();
		}
		public String getHostMonitor() {
			return mConexion.getHost();
		}
		public void addConexionMonitor(InfoSocket cliente, InfoSocket destino) {
			mConexion.addConexion(cliente.getIDCliente(), destino.getIDCliente());
		}
		public void aumentaPuertoMonitor() {
			mConexion.aumentaPuerto();
		}
		public void esperaFinConexionMonitor(String conexion) {
			// Mientras que haya conexion se mantiene en el bucle
			while(mConexion.getConexiones().get(conexion)) {
				// Para que este durmiendo un rato y no este constantemente
				// accediendo al monitor 
				try {					
					Thread.sleep(5000);
				} catch (InterruptedException e) {	
					System.out.println("Excepcion en OyentePeerToPeer");
				}
			}
		}
		
}
